singleton Material(Mat_RallyCar_Main)
{
   mapTo = "_1_-_Default";
   diffuseMap[0] = "art/shapes/RallyCar/RallyCar_Base_Dif.png";
   specular[0] = "0.9 0.9 0.9 1";
   specularPower[0] = "1";
   translucentBlendOp = "None";
};

singleton Material(Mat_RallyCar_Glass)
{
   mapTo = "_2_-_Default";
   diffuseMap[0] = "art/shapes/RallyCar/Glass.png";
   specular[0] = "0.9 0.9 0.9 1";
   specularPower[0] = "1";
   translucent = "1";
   translucentBlendOp = "Sub";
   alphaRef = "0";
};

singleton Material(RallyCarTire__3___Default)
{
   mapTo = "_3_-_Default";
   diffuseMap[0] = "Tire_Dif";
   specular[0] = "0.9 0.9 0.9 1";
   specularPower[0] = "1";
   translucentBlendOp = "None";
};

singleton Material(RallyCar_ColorEffectR177G148B27_material)
{
   mapTo = "ColorEffectR177G148B27-material";
   diffuseColor[0] = "0.694118 0.580392 0.105882 1";
   specularPower[0] = "10";
   translucentBlendOp = "None";
};


//Add skins here
singleton Material(Mat_Blue_RallyCar_Main : Mat_RallyCar_Main)
{
   mapTo = "_1_-_Default";
   diffuseMap[0] = "RallyCar_Blue_Dif.png";
};

singleton Material(Mat_Green_RallyCar_Main : Mat_RallyCar_Main)
{
   mapTo = "_1_-_Default";
   diffuseMap[0] = "RallyCar_Green_Dif.png";
};

singleton Material(Mat_Orange_RallyCar_Main : Mat_RallyCar_Main)
{
   mapTo = "_1_-_Default";
   diffuseMap[0] = "RallyCar_Orange_Dif.png";
};

singleton Material(Mat_Black_RallyCar_Main : Mat_RallyCar_Main)
{
   mapTo = "_1_-_Default";
   diffuseMap[0] = "RallyCar_Black_Dif.png";
};

singleton Material(Mat_Violet_RallyCar_Main : Mat_RallyCar_Main)
{
   mapTo = "_1_-_Default";
   diffuseMap[0] = "RallyCar_Violet_Dif.png";
};

singleton Material(Mat_Yellow_RallyCar_Main : Mat_RallyCar_Main)
{
   mapTo = "_1_-_Default";
   diffuseMap[0] = "RallyCar_Yellow_Dif.png";
};

//END Skins//

