//-----------------------------------------------------------------------------
// Copyright (c) 2012 GarageGames, LLC
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//-----------------------------------------------------------------------------

singleton TSShapeConstructor(RallyDAE)
{
   baseShape = "./RallyCar.DAE";
   loadLights = "0";
   lodType = "TrailingNumber";
   neverImport = "null  EnvironmentAmbientLight";
   forceUpdateMaterials = "0";
   loadLights = "0";
};

function RallyDAE::onLoad(%this)
{
   %this.setSequenceCyclic("ambient", "0");
   %this.renameSequence("ambient", "timeline");
   %this.addSequence("timeline", "spring0", "0", "1", "1", "0");
   %this.addSequence("timeline", "spring1", "2", "3", "1", "0");
   %this.addSequence("timeline", "spring2", "4", "5", "1", "0");
   %this.addSequence("timeline", "spring3", "6", "7", "1", "0");
   %this.addSequence("timeline", "steering", "8", "9", "1", "0");
   %this.addNode("Col-1", "", "0 0 0 0 0 1 0", "0");
   %this.addCollisionDetail("-1", "10-DOP X", "Body", "4", "30", "30", "32", "30", "30", "30");
}
