//-----------------------------------------------------------------------------
// Copyright (c) 2012 GarageGames, LLC
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//-----------------------------------------------------------------------------

function RallyCar::onAdd(%this, %obj)
{
   Parent::onAdd(%this, %obj);

   %obj.setWheelTire(0,RallyCarTire);
   %obj.setWheelTire(1,RallyCarTire);
   %obj.setWheelTire(2,RallyCarTire);
   %obj.setWheelTire(3,RallyCarTire);

   // Setup the car with some tires & springs
   for (%i = %obj.getWheelCount() - 1; %i >= 0; %i--)
   {
      %obj.setWheelPowered(%i, true);
      %obj.setWheelSpring(%i, RallyCarSpring);
   }

   // Steer with the front tires
   %obj.setWheelSteering(0, 1);
   %obj.setWheelSteering(1, 1);
	
 // Add tail lights
   %obj.rightBrakeLight = new PointLight() 
   {
      radius = "1";
      isEnabled = "0";
      color = "1 0 0.141176 1";
      brightness = "2";
      castShadows = "1";
      priority = "1";
      animate = "0";
      animationPeriod = "1";
      animationPhase = "1";
      flareScale = "1";
      attenuationRatio = "0 1 1";
      shadowType = "DualParaboloidSinglePass";
      texSize = "512";
      overDarkFactor = "2000 1000 500 100";
      shadowDistance = "400";
      shadowSoftness = "0.15";
      numSplits = "1";
      logWeight = "0.91";
      fadeStartDistance = "0";
      lastSplitTerrainOnly = "0";
      representedInLightmap = "0";
      shadowDarkenColor = "0 0 0 -1";
      includeLightmappedGeometryInShadow = "0";
      rotation = "1 0 0 0";
      canSave = "1";
      canSaveDynamicFields = "1";
         splitFadeDistances = "10 20 30 40";
   };
   %obj.leftBrakeLight = new PointLight() 
   {
      radius = "1";
      isEnabled = "0";
      color = "1 0 0.141176 1";
      brightness = "2";
      castShadows = "1";
      priority = "1";
      animate = "0";
      animationPeriod = "1";
      animationPhase = "1";
      flareScale = "1";
      attenuationRatio = "0 1 1";
      shadowType = "DualParaboloidSinglePass";
      texSize = "512";
      overDarkFactor = "2000 1000 500 100";
      shadowDistance = "400";
      shadowSoftness = "0.15";
      numSplits = "1";
      logWeight = "0.91";
      fadeStartDistance = "0";
      lastSplitTerrainOnly = "0";
      representedInLightmap = "0";
      shadowDarkenColor = "0 0 0 -1";
      includeLightmappedGeometryInShadow = "0";
      rotation = "1 0 0 0";
      canSave = "1";
      canSaveDynamicFields = "1";
         splitFadeDistances = "10 20 30 40";
   };
   // Add Reverse lights
   %obj.rightReverseLight = new PointLight() 
   {
      radius = "1";
      isEnabled = "0";
      color = "1 1 1 1";
      brightness = "2";
      castShadows = "1";
      priority = "1";
      animate = "0";
      animationPeriod = "1";
      animationPhase = "1";
      flareScale = "1";
      attenuationRatio = "0 1 1";
      shadowType = "DualParaboloidSinglePass";
      texSize = "512";
      overDarkFactor = "2000 1000 500 100";
      shadowDistance = "400";
      shadowSoftness = "0.15";
      numSplits = "1";
      logWeight = "0.91";
      fadeStartDistance = "0";
      lastSplitTerrainOnly = "0";
      representedInLightmap = "0";
      shadowDarkenColor = "0 0 0 -1";
      includeLightmappedGeometryInShadow = "0";
      rotation = "1 0 0 0";
      canSave = "1";
      canSaveDynamicFields = "1";
         splitFadeDistances = "10 20 30 40";
   };
   %obj.leftReverseLight = new PointLight() 
   {
      radius = "1";
      isEnabled = "0";
      color = "1 1 1 1";
      brightness = "2";
      castShadows = "1";
      priority = "1";
      animate = "0";
      animationPeriod = "1";
      animationPhase = "1";
      flareScale = "1";
      attenuationRatio = "0 1 1";
      shadowType = "DualParaboloidSinglePass";
      texSize = "512";
      overDarkFactor = "2000 1000 500 100";
      shadowDistance = "400";
      shadowSoftness = "0.15";
      numSplits = "1";
      logWeight = "0.91";
      fadeStartDistance = "0";
      lastSplitTerrainOnly = "0";
      representedInLightmap = "0";
      shadowDarkenColor = "0 0 0 -1";
      includeLightmappedGeometryInShadow = "0";
      rotation = "1 0 0 0";
      canSave = "1";
      canSaveDynamicFields = "1";
         splitFadeDistances = "10 20 30 40";
   };
   // Add head lights
   %obj.rightHeadLight = new SpotLight() 
   {
      radius = "1";
	  range = "15";			//Edit was 10
	  innerAngle = "40";
	  outerAngle = "45";
      isEnabled = "0";
      color = "1 1 1 1";
      brightness = "5";		//Edit was 1
      castShadows = "1";
      priority = "1";
      animate = "0";
      animationPeriod = "1";
      animationPhase = "1";
	  flareType = "LightFlareExample0";
      flareScale = "0.5";
      attenuationRatio = "0 1 1";
      shadowType = "DualParaboloidSinglePass";
	  //cookie = "art/shapes/ScrapScout/images/Light.png";
      texSize = "512";
      overDarkFactor = "2000 1000 500 100";
      shadowDistance = "400";
      shadowSoftness = "0.15";
      numSplits = "1";
      logWeight = "0.91";
      fadeStartDistance = "0";
      lastSplitTerrainOnly = "0";
      representedInLightmap = "0";
      shadowDarkenColor = "0 0 0 -1";
      includeLightmappedGeometryInShadow = "0";
      rotation = "1 0 0 0";
      canSave = "1";
      canSaveDynamicFields = "1";
         splitFadeDistances = "10 20 30 40";
   };
   %obj.leftHeadLight = new SpotLight() 
   {
      radius = "1";
	  range = "15";			//Edit was 10
	  innerAngle = "40";
	  outerAngle = "45";
      isEnabled = "0";
      color = "1 1 1 1";
      brightness = "5";		//Edit was 1
      castShadows = "1";
      priority = "1";
      animate = "0";
      animationPeriod = "1";
      animationPhase = "1";
	  flareType = "LightFlareExample0";
      flareScale = "0.5";
      attenuationRatio = "0 1 1";
      shadowType = "DualParaboloidSinglePass";
	  //cookie = "art/shapes/ScrapScout/images/Light.png";
      texSize = "512";
      overDarkFactor = "2000 1000 500 100";
      shadowDistance = "400";
      shadowSoftness = "0.15";
      numSplits = "1";
      logWeight = "0.91";
      fadeStartDistance = "0";
      lastSplitTerrainOnly = "0";
      representedInLightmap = "0";
      shadowDarkenColor = "0 0 0 -1";
      includeLightmappedGeometryInShadow = "0";
      rotation = "1 0 0 0";
      canSave = "1";
      canSaveDynamicFields = "1";
         splitFadeDistances = "10 20 30 40";
   };
   // Add turn lights
   %obj.rightTurnLight = new PointLight() 
   {
      radius = "1";
      isEnabled = "0";
	  color = "0.996078 0.807843 0.00784314 1";
      brightness = "2";		//Edit was 1
      castShadows = "1";
      priority = "1";
      animate = "1";
	  animationType = "FlickerLightAnim";
      animationPeriod = "1";
      animationPhase = "1";
      flareScale = "1";
      attenuationRatio = "0 1 1";
      shadowType = "DualParaboloidSinglePass";
      texSize = "512";
      overDarkFactor = "2000 1000 500 100";
      shadowDistance = "400";
      shadowSoftness = "0.15";
      numSplits = "1";
      logWeight = "0.91";
      fadeStartDistance = "0";
      lastSplitTerrainOnly = "0";
      representedInLightmap = "0";
      shadowDarkenColor = "0 0 0 -1";
      includeLightmappedGeometryInShadow = "0";
      rotation = "1 0 0 0";
      canSave = "1";
      canSaveDynamicFields = "1";
         splitFadeDistances = "10 20 30 40";
   };
   %obj.leftTurnLight = new PointLight() 
   {
      radius = "1";
      isEnabled = "0";
      color = "0.996078 0.807843 0.00784314 1";
      brightness = "2";		//Edit was 1
      castShadows = "1";
      priority = "1";
      animate = "1";
	  animationType = "FlickerLightAnim";
      animationPeriod = "1";
      animationPhase = "1";
      flareScale = "1";
      attenuationRatio = "0 1 1";
      shadowType = "DualParaboloidSinglePass";
      texSize = "512";
      overDarkFactor = "2000 1000 500 100";
      shadowDistance = "400";
      shadowSoftness = "0.15";
      numSplits = "1";
      logWeight = "0.91";
      fadeStartDistance = "0";
      lastSplitTerrainOnly = "0";
      representedInLightmap = "0";
      shadowDarkenColor = "0 0 0 -1";
      includeLightmappedGeometryInShadow = "0";
      rotation = "1 0 0 0";
      canSave = "1";
      canSaveDynamicFields = "1";
         splitFadeDistances = "10 20 30 40";
   };
   
   // Add Exhaust Particles
   %leftExhaust = new ParticleEmitterNode()
   {
		datablock = SmokeEmitterNode;
		active = true;
		emitter = ExhaustEmitter;
		velocity = 3.5;
   };
   %rightExhaust = new ParticleEmitterNode()
   {
		datablock = SmokeEmitterNode;
		active = true;
		emitter = ExhaustEmitter;
		velocity = 3.5;
   };

   // Mount a ShapeBaseImageData
   //%didMount = %obj.mountImage(TurretImage, %this.turretSlot);

   // Mount the brake lights
   %obj.mountObject(%obj.rightBrakeLight, %this.rightBrakeSlot, "0 0 0");//mountobject(%obj, mountNode, mountOffset)
   %obj.mountObject(%obj.leftBrakeLight, %this.leftBrakeSlot, "0 0 0");//mountobject(%obj, mountNode, mountOffset)
   
   // Mount the reverse lights
   %obj.mountObject(%obj.rightReverseLight, %this.rightBrakeSlot, "0.25 0 0");//mountobject(%obj, mountNode, mountOffset)
   %obj.mountObject(%obj.leftReverseLight, %this.leftBrakeSlot, "-0.25 0 0");//mountobject(%obj, mountNode, mountOffset)
   
   // Mount the head lights
   %obj.mountObject(%obj.rightHeadLight, %this.rightHeadSlot, "0 0.05 0");//mountobject(%obj, mountNode, mountOffset)
   %obj.mountObject(%obj.leftHeadLight, %this.leftHeadSlot, "0 0.05 0");//mountobject(%obj, mountNode, mountOffset)
   
   // Mount the turn lights
   %obj.mountObject(%obj.rightTurnLight, %this.rightBrakeSlot, "0.4 0.2 0");//mountobject(%obj, mountNode, mountOffset)
   %obj.mountObject(%obj.leftTurnLight, %this.leftBrakeSlot, "-0.4 0.2 0");//mountobject(%obj, mountNode, mountOffset)
   
   // Mount Exhaust Particles
   %obj.mountObject(%rightExhaust, %this.rightBrakeSlot, "-0.125 -0.125 -0.4");//mountobject(%obj, mountNode, mountOffset)
   %obj.mountObject(%leftExhaust, %this.leftBrakeSlot, "0.125 -0.125 -0.4");//mountobject(%obj, mountNode, mountOffset)
   
   //Pick Random Vehicle Material
   %mapTo = %obj.getTargetName( 1 );//_1_-_Default or Body material slot
   %mapTo2 = %obj.getTargetName( 0 );//_2_-_Default or Glass material slot
   
   %RandomSkin = getRandom(6);                      
         switch(%RandomSkin)                                
         {
            case 0:
            %NewMat = "Mat_RallyCar_Main";
            case 1:
            %NewMat = "Mat_Blue_RallyCar_Main"; 
            case 2:
            %NewMat = "Mat_Green_RallyCar_Main"; 
            case 3:
            %NewMat = "Mat_Orange_RallyCar_Main";  
            case 4:
			%NewMat = "Mat_Black_RallyCar_Main";
			case 5:
			%NewMat = "Mat_Violet_RallyCar_Main";
			case 6:
			%NewMat = "Mat_Yellow_RallyCar_Main";
               
         }
   
   %obj.changeMaterial( %mapTo, Mat_Yellow_RallyCar_Main, %NewMat );
   %obj.changeMaterial( %mapTo2, Mat_RallyCar_Glass, Mat_RallyCar_Glass );
 }

function RallyCar::onRemove(%this, %obj)
{
   Parent::onRemove(%this, %obj);

   if(isObject(%obj.rightBrakeLight))
      %obj.rightBrakeLight.delete();

   if(isObject(%obj.leftBrakeLight))
      %obj.leftBrakeLight.delete();
	  
	if(isObject(%obj.rightReverseLight))
      %obj.rightReverseLight.delete();

   if(isObject(%obj.leftReverseLight))
      %obj.leftReverseLight.delete();
	  
	if(isObject(%obj.rightHeadLight))
      %obj.rightHeadLight.delete();

   if(isObject(%obj.leftHeadLight))
      %obj.leftHeadLight.delete();
	  
	if(isObject(%obj.rightTurnLight))
      %obj.rightTurnLight.delete();

   if(isObject(%obj.leftTurnLight))
      %obj.leftTurnLight.delete();

   if(isObject(%obj.turret))
      %obj.turret.delete();
}

function serverCmdtoggleBrakeLights(%client)
{
   %car = %client.player.getControlObject();

   if (%car.getClassName() $= "WheeledVehicle")
   {
      if(%car.rightBrakeLight.isEnabled)
      {
         %car.rightBrakeLight.setLightEnabled(0);
         %car.leftBrakeLight.setLightEnabled(0);
      }
      else
      {
         %car.rightBrakeLight.setLightEnabled(1);
         %car.leftBrakeLight.setLightEnabled(1);
      }
   }
}

function serverCmdtoggleReverseLights(%client)
{
   %car = %client.player.getControlObject();

   if (%car.getClassName() $= "WheeledVehicle")
   {
      if(%car.rightReverseLight.isEnabled)
      {
        %car.rightReverseLight.setLightEnabled(0);
        %car.leftReverseLight.setLightEnabled(0);
      }
      else
      {
         %car.rightReverseLight.setLightEnabled(1);
         %car.leftReverseLight.setLightEnabled(1);
      }
   }
}

function serverCmdtoggleHeadLights(%client)
{
   %car = %client.player.getControlObject();

   if (%car.getClassName() $= "WheeledVehicle")
   {
      if(%car.rightHeadLight.isEnabled)
      {
         %car.rightHeadLight.setLightEnabled(0);
         %car.leftHeadLight.setLightEnabled(0);
      }
      else
      {
         %car.rightHeadLight.setLightEnabled(1);
         %car.leftHeadLight.setLightEnabled(1);
      }
   }
}

function serverCmdtoggleRtTurnLight(%client)
{
   %car = %client.player.getControlObject();

   if (%car.getClassName() $= "WheeledVehicle")
   {
      if(%car.rightTurnLight.isEnabled)
      {
         %car.rightTurnLight.setLightEnabled(0);
      }
      else
      {
         %car.rightTurnLight.setLightEnabled(1);
      }
   }
}

function serverCmdtoggleLtTurnLight(%client)
{
   %car = %client.player.getControlObject();

   if (%car.getClassName() $= "WheeledVehicle")
   {
      if(%car.leftTurnLight.isEnabled)
      {
         %car.leftTurnLight.setLightEnabled(0);
      }
      else
      {
         %car.leftTurnLight.setLightEnabled(1);
      }
   }
}

// Callback invoked when an input move trigger state changes when the CheetahCar
// is the control object
function RallyCarCar::onTrigger(%this, %obj, %index, %state)
{
   // Pass trigger states on to TurretImage (to fire weapon)
   switch ( %index )
   {
      case 0:  %obj.setImageTrigger( %this.turretSlot, %state );
      case 1:  %obj.setImageAltTrigger( %this.turretSlot, %state );
   }
}

function TurretImage::onMount(%this, %obj, %slot)
{
   // Load the gun
   %obj.setImageAmmo(%slot, true);
}