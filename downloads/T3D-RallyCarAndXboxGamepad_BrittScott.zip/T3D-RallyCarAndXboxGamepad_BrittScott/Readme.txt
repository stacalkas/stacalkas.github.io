[11/05/16]
Torque3D Rally Car and Xbox Controller/Gamepad Resources

1. Place "art" and "scripts" folders based on their folder hierarchy. Everything else is either reference or source files.

2. Run Torque3D and open World Editor.

3. Under Scene Tree, click "Library" tab -> click "Scripted" tab
-> click "Vehicles" folder -> click "RallyCar"

4. Exit world editor and walk into car to drive.

Vehicle features:
-headlights
-turn signals
-brake lights
-reverse lights
(These all do work, but are not working as intended.)

Xbox One Gamepad:
//Vehicle//
Button Y		Get out of car
Button B		Brake
Left Trigger		Reverse
Right Trigger		Forward
Left Stick Click	Headlights
Left Bumper		Left Turn Signal
Right Bumper		Right Turn Signal

//Player//
Button Y		1st/3rd person
Button X		Reload
Button B		Crouch
Button A		Jump
Left Trigger		Zoom
Right Trigger		Use Weapon
Left Bumper		Prev Weapon
Right Bumper		Next Weapon
Left Stick Click	Sprint(hard to use)

Youtube video:  https://youtu.be/JYSse4S3CBc
