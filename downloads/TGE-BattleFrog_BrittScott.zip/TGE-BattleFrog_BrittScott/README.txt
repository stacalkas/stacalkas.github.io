/////////////////////////////////
//Battle Frog Readme//
////////////////////////////////////////////////////////
Modified by:	Britt Scott
Object Class:	Wheeled Vehicle
SubClass:	Battle Frog
UPDATED:	Sept 8, 2008
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////

SETUP:

1. "LeftHeadLight.cs" and "RightHeadLight.cs". need to be placed in /common/lighting/lights
2. "BattleFrog.cs" needs placed in /server/scripts
3. "BattleFrog" folder needs placed in /data/shapes

4a. Open the "main.cs" located in the root folder of Torque.
4b. Make sure in "main.cs", $defaultGame = "starter.racing";

5a. Open the "game.cs" located in /server/scripts
5b. Find the line: exec("./car.cs");
5c. Change this line to(or comment out): //exec("./car.cs");
5d. After: //exec("./car.cs"); 

	Add:

	exec("./BattleFrog.cs");
	exec("common/server/lightingSystem.cs");

NOTES:

1. Tested for TGE 1.5.2 in starter.racing
2. Use "Tab" to switch between 1st person and 3rd person.  I prefer using 3rd person.
3. Vehicle physics settings will more than likely need to be "tuned" to fit your gameplay! However, I believe the current setup is a good starting point.  Vehicle is currently setup for 4WD, 4-wheel steering, with Rear wheels counter-steering.
4. "BattleFrog.cs" depends upon "LeftHeadLight.cs" and "LeftHeadLight.cs", in order for the headlights to work.  
These depend upon "lightingSystem.cs" being executed in the "game.cs"  The headlights didn't turn out 
the way that I had hoped, but then again I couldn't really find a "How-To-Add-Headlights"  So, as with the 
vehicle physics, these will more than likely need to be "tuned"
5. A serparate glass texture was made because I was having problems with the alpha on the texture as a whole. 
6. I used "swappable base textures", so if someone wanted to change the skin via script, they could.  A UVW template is provided in the "BattleFrog" folder.
7. Also the BattleFrog was textured using symmetry.  So kept that in mind, when re-texturing.
 
	         