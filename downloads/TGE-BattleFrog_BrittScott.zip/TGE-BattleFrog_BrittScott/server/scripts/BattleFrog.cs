//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
// Modified by:      Britt Scott
// Object Class:     Wheeled Vehicle
// SubClass:         Battle Frog
// UPDATED:          Sept 8, 2008
//-----------------------------------------------------------------------------

// Information extacted from the shape.
//
// Wheel Sequences
//    spring#        Wheel spring motion: time 0 = wheel fully extended,
//                   the hub must be displaced, but not directly animated
//                   as it will be rotated in code.
// Other Sequences
//    steering       Wheel steering: time 0 = full right, 0.5 = center
//    breakLight     Break light, time 0 = off, 1 = breaking
//
// Wheel Nodes
//    hub#           Wheel hub, the hub must be in it's upper position
//                   from which the springs are mounted.
//
// The steering and animation sequences are optional.
// The center of the shape acts as the center of mass for the car.

//-----------------------------------------------------------------------------
datablock AudioProfile(BattleFrogEngineSound)
{
   filename    = "~/data/sound/vehicles/BattleFrog/engine_idle.wav";
   description = AudioClosestLooping3d;
   preload = true;
};

datablock ParticleData(TireParticle)
{
   textureName          = "~/data/shapes/BattleFrog/dustParticle";
   dragCoefficient      = 2.0;
   gravityCoefficient   = -0.1;
   inheritedVelFactor   = 0.1;
   constantAcceleration = 0.0;
   lifetimeMS           = 1000;
   lifetimeVarianceMS   = 400;
   colors[0]     = "0.46 0.36 0.26 1.0";
   colors[1]     = "0.46 0.46 0.36 0.0";
   sizes[0]      = 1.0;
   sizes[1]      = 4.0;
};

datablock ParticleEmitterData(TireEmitter)
{
   ejectionPeriodMS = 20;
   periodVarianceMS = 10;
   ejectionVelocity = 1;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "TireParticle";
};


//----------------------------------------------------------------------------

datablock WheeledVehicleTire(DefaultCarTire)
{
   // Tires act as springs and generate lateral and longitudinal
   // forces to move the vehicle. These distortion/spring forces
   // are what convert wheel angular velocity into forces that
   // act on the rigid body.
   shapeFile = "~/data/shapes/BattleFrog/Swamper.dts";
   staticFriction = 4.2;
   kineticFriction = 3.15;

   // Spring that generates lateral tire forces
   lateralForce = 18000;
   lateralDamping = 6000;
   lateralRelaxation = 1;

   // Spring that generates longitudinal tire forces
   longitudinalForce = 18000;
   longitudinalDamping = 4000;
   longitudinalRelaxation = 1;
};

datablock WheeledVehicleSpring(DefaultCarSpring)
{
   // Wheel suspension properties
   length = 0.55;             // Suspension travel       ////REF: Was 0.85
   force = 3800;              // Spring force            ////REF: Was 2800
   damping = 760;             // Spring damping          ////REF: Was 3600
   antiSwayForce = 2;         // Lateral anti-sway force ////REF: Was 2
};

datablock WheeledVehicleData(DefaultCar)
{
   category = "Vehicles";
   shapeFile = "~/data/shapes/BattleFrog/BattleFrog.dts";
   emap = true;
   
   multipassenger = true;
   mountPose[0] = sitting;
   mountPose[1] = sitting;
   numMountPoints = 2;

   maxDamage = 1.0;
   destroyedLevel = 0.5;

   maxSteeringAngle = 0.4;  // Maximum steering angle, should match animation  ////REF: 0.6 causes "turn on a dime"
   tireEmitter = TireEmitter; // All the tires use the same dust emitter

   // 3rd person camera settings
   cameraRoll = false;           // Roll the camera with the vehicle
   cameraMaxDist = 10;				// Maximum distance that the camera will lag behind the object when in motion when in 3rd person
	cameraMinDist = 5;				// Minimum distance that the camera will travel from the node location when in 3rd person
	cameraDefaultFov = 90.0;		// Default FOV for this object (used if observeThroughObject is set to true)
	cameraMinFov = 5.0;				// Minimum value for FOV that the camera can be set to when observing through this object/observeThroughObject Must be set to True!
	cameraMaxFov = 120.0;			// Maximum value for FOV that the camera can be set to when observing through this object/observeThroughObject Must be set to True!
	firstPersonOnly = false;		// prevent 3rd person mode
	useEyePoint = false;				// use the eye node for all camera locations
	observeThroughObject = true;	// use the object's camera FOV settings and cam node transform
   cameraOffset = 4.5;           // Vertical offset from camera mount point   //EDIT was 1.5
   cameraLag = 0.3;              // Velocity lag of camera                    //EDIT was 0.26
   cameraDecay = 1.25;           // Decay per sec. rate of velocity lag       //EDIT was 1.25
   cameraOffset = 1.5;           // Vertical offset from camera mount point
   cameraLag = 0.26;             // Velocity lag of camera
   cameraDecay = 1.25;           // Decay per sec. rate of velocity lag

   // Rigid Body
   mass = 380;
   massCenter = "0 -0.2 0";    // Center of mass for rigid body
   massBox = "0 0 0";         // Size of box used for moment of inertia,
                              // if zero it defaults to object bounding box
   drag = 0.6;                // Drag coefficient
   bodyFriction = 0.6;
   bodyRestitution = 0.4;
   minImpactSpeed = 5;        // Impacts over this invoke the script callback
   softImpactSpeed = 5;       // Play SoftImpact Sound
   hardImpactSpeed = 15;      // Play HardImpact Sound
   integration = 8;           // Physics integration: TickSec/Rate
   collisionTol = 0.1;        // Collision distance tolerance
   contactTol = 0.1;          // Contact velocity tolerance

   // Engine
   engineTorque = 3300;       // Engine power                                 ////REF: Was 3300
   engineBrake = 600;         // Braking when throttle is 0
   brakeTorque = 8000;        // When brakes are applied
   maxWheelSpeed = 50;        // Engine scale by current speed / max speed

   // Energy
   maxEnergy = 100;
   jetForce = 3000;
   minJetEnergy = 30;
   jetEnergyDrain = 2;

   // Sounds
//   jetSound = ScoutThrustSound;
//   engineSound = BuggyEngineSound;
//   squealSound = ScoutSquealSound;
//   softImpactSound = SoftImpactSound;
//   hardImpactSound = HardImpactSound;
//   wheelImpactSound = WheelImpactSound;

//   explosion = VehicleExplosion;
};


//-----------------------------------------------------------------------------

function WheeledVehicleData::create(%block)
{
   %obj = new WheeledVehicle() {
      dataBlock = %block;
   };
   return(%obj);
}

//-----------------------------------------------------------------------------

function WheeledVehicleData::onAdd(%this,%obj)
{
   // Setup the car with some defaults tires & springs
   for (%i = %obj.getWheelCount() - 1; %i >= 0; %i--) {
      %obj.setWheelTire(%i,DefaultCarTire);
      %obj.setWheelSpring(%i,DefaultCarSpring);
      %obj.setWheelPowered(%i,false);
   }
   
   // Tire Steering                 ////REF: 4WD Steering. Rear Wheels set to countersteer using "-1"
   %obj.setWheelSteering(0,1);      //Front Left  Tire
   %obj.setWheelSteering(1,1);      //Front Right Tire
   %obj.setWheelSteering(2,-1);     //Rear  Left  Tire
   %obj.setWheelSteering(3,-1);     //Rear  Right Tire
   

   // Drivetrain                    ////REF: 4WD drivetrain
   %obj.setWheelPowered(0,true);    //Front Left  Tire
   %obj.setWheelPowered(1,true);    //Front Right Tire
   %obj.setWheelPowered(2,true);    //Rear  Left  Tire
   %obj.setWheelPowered(3,true);    //Rear  Right Tire

//Battle Frog Lights//           ////REF:  See: common/lighting/lights/HeadLight.cs  
                                 ////      and common/lighting/lights/HeadLightSpot.cs 
                                 ////Note: Headlight.cs sets the mount node that
                                 ////      the light attaches to and its rotation
////LEFT HEAD LIGHT////                                                      
   %light = new volumeLight()    
   {
      dataBlock = "LeftHeadLightShine";
      rotation = "-0.357694 0.933839 9.9834e-009 180";
      scale = "1 1 1";
      dataBlock = "LeftHeadLightShine";
      Enable = "1";
      IconSize = "1";
      ParticleColorAttenuation = "1";
      Texture = "common/lighting/lightFalloffMono.png";
      lpDistance = "0.75";                ////REF: was 0.35
      ShootDistance = "15";               ////REF: was 5
      Xextent = "0.6";                    
      Yextent = "0.6";                    
      SubdivideU = "4";
      SubdivideV = "4";
      FootColour = "1.000000 1.000000 1.000000 0.182000";
      TailColour = "0.000000 0.000000 0.000000 0.000000";
   };
   %light.attachtoobject(%obj);
   
   %light = new volumeLight()                         
   {
      dataBlock = "LeftHeadLightSpot";
      rotation = "-0.357694 0.933839 9.9834e-009 180";
      scale = "1 1 1";
      dataBlock = "LeftHeadLightSpot";
      Enable = "1";
      IconSize = "1";
      ParticleColorAttenuation = "1";
      //Texture = "common/lighting/lightFalloffMono.png";
      lpDistance = "0.35";
      ShootDistance = "10";//Ref: was 5
      Xextent = "0.6";
      Yextent = "0.6";
      SubdivideU = "4";
      SubdivideV = "4";
      FootColour = "1.000000 1.000000 1.000000 0.182000";
      TailColour = "0.000000 0.000000 0.000000 0.000000";
   };
   %light.attachtoobject(%obj);
  
 ////RIGHT HEAD LIGHT//// 
   
   %light = new volumeLight()    
   {
      dataBlock = "RightHeadLightShine";
      rotation = "-0.357694 0.933839 9.9834e-009 180";
      scale = "1 1 1";
      dataBlock = "RightHeadLightShine";
      Enable = "1";
      IconSize = "1";
      ParticleColorAttenuation = "1";
      Texture = "common/lighting/lightFalloffMono.png";
      lpDistance = "0.75";                ////REF: was 0.35
      ShootDistance = "15";               ////REF: was 5
      Xextent = "0.6";                    
      Yextent = "0.6";                    
      SubdivideU = "4";
      SubdivideV = "4";
      FootColour = "1.000000 1.000000 1.000000 0.182000";
      TailColour = "0.000000 0.000000 0.000000 0.000000";
   };
   %light.attachtoobject(%obj);
   
   %light = new volumeLight()                         
   {
      dataBlock = "RightHeadLightSpot";
      rotation = "-0.357694 0.933839 9.9834e-009 180";
      scale = "1 1 1";
      dataBlock = "RightHeadLightSpot";
      Enable = "1";
      IconSize = "1";
      ParticleColorAttenuation = "1";
      //Texture = "common/lighting/lightFalloffMono.png";
      lpDistance = "0.35";
      ShootDistance = "10";//Ref: was 5
      Xextent = "0.6";
      Yextent = "0.6";
      SubdivideU = "4";
      SubdivideV = "4";
      FootColour = "1.000000 1.000000 1.000000 0.182000";
      TailColour = "0.000000 0.000000 0.000000 0.000000";
   };
   %light.attachtoobject(%obj);
}

function WheeledVehicleData::onCollision(%this,%obj,%col,%vec,%speed)
{
   // Collision with other objects, including items
} 