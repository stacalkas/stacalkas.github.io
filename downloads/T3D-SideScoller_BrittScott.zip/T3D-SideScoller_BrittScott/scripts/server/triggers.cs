//-----------------------------------------------------------------------------
// Copyright (c) 2012 GarageGames, LLC
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// DefaultTrigger is used by the mission editor.  This is also an example
// of trigger methods and callbacks.

function DefaultTrigger::onEnterTrigger(%this,%trigger,%obj)
{
   // This method is called whenever an object enters the %trigger
   // area, the object is passed as %obj.
}

function DefaultTrigger::onLeaveTrigger(%this,%trigger,%obj)
{
   // This method is called whenever an object leaves the %trigger
   // area, the object is passed as %obj.
}

function DefaultTrigger::onTickTrigger(%this,%trigger)
{
   // This method is called every tickPerioMS, as long as any
   // objects intersect the trigger.

   // You can iterate through the objects in the list by using these
   // methods:
   //    %trigger.getNumObjects();
   //    %trigger.getObject(n);
}

//Add Side Scroller Triggers MyEdit
function KillTrigger::onTickTrigger(%this,%trigger)
{
   commandToServer('Suicide');
   warn("Player Killed");
}

function VictoryTrigger::onEnterTrigger(%this,%trigger, %col)
{
   if (%col.getClassName() $= "player")
   {
	warn("Victory Enter");
	%col.playThread(0, "Celebrate_01");
   }
 
   
}

function PrizeTrigger::onEnterTrigger(%this,%trigger)
{
   
   warn("Prize Awarded");
   
   %item = ItemData::createItem(PickupLurker);
   %item.sourceObject = %this;
   %item.static = false;
   %item.rotate = false;
   MissionCleanup.add(%item);

   //%vec = (-1.0 + getRandom() * 2.0) SPC (-1.0 + getRandom() * 2.0) SPC getRandom();
   %vec = (0) SPC (1) SPC getRandom();
   //%vec = vectorScale(%vec, 10);
   %vec = vectorScale(%vec, 2);
   %vec = vectorAdd(%vec, vectorScale("0 0 8", 1 ));
   %pos = getBoxCenter(%trigger.getWorldBox());

   %item.setTransform(%pos);
   %item.applyImpulse(%pos, %vec);
   %item.setCollisionTimeout(%this);
   //serverPlay3D(%item.getDataBlock().throwSound, %item.getTransform());
   %item.schedulePop();

   return %item;
}

function SpawnEnemyTrigger::onLeaveTrigger(%this,%trigger)
{
 /*  
//activate when player enters

	//%checkclass = %obj.getclassname();
	//if(%checkclass $= "Player")
	   if(!isObject(zombie1))
	   {
		  %zombie = aiplayer::spawnBot(zombie1, botspawn1);
		  %zombie.followPath("EnemyPatrol");
		  
		  //%zombie.setMoveDestination(MoveHere.getPosition());
		  warn("Zombie1 spawned");
		}
		*/
		
		if(!isObject(Enemy))
	   {
		  %enemy = aiplayer::spawnAtLocation("Enemy", "botspawn1");
		  %enemy.followPath("EnemyPatrol");
		  
		  
		  //%zombie.setMoveDestination(MoveHere.getPosition());
		  warn("Enemy1 spawned");
		}
		
}