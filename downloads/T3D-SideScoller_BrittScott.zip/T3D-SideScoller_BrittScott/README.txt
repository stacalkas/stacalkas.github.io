[12/09/16]
Torque3D Side Scroller


Place "art" and "scripts" folders based on their folder hierarchy. The .png and .psd files are source or reference files.

Then create a new level.

/////////////////////////////
//Scripts added or modified//
/////////////////////////////

art/datablocksExec.cs // Added PickupLurker.cs and CrosshairTP.cs so it can be executed

art/datablocks/player.cs // Changed jumpForce, so player jumps higher

art/datablocks/PickupLurker.cs // Created new script file for Lurker Pickup declaration

art/datablocks/CrosshairTP.cs //Created new script file for Crosshair Third person

art/datablocks/triggers.cs  //Added new Trigger declarations

art/datablocks/weapons/Lurker.cs //changed to 2d sound

art/datablocks/weapons/Ryder.cs //changed to 2d sound

scripts/client/default.bind.cs // Changed it so the move controls are different, changed camera direction and disable one axis of the mouse

scripts/server/gameCore.cs // change player startup inventory, also setup new camera and keep camera upon death
				
scripts/server/player.cs // mount third person crosshair to player

scripts/server/commands.cs // Added server command to change camera direction

scripts/server/triggers.cs //Added Trigger commands

scripts/server/Pickups.cs // Created new script file for pickups

scripts/server/scriptExec.cs // Added pickups.cs so it can be executed

scripts/server/aiPlayer.cs // Changed Ai Behavior

/////////////////////////////
//Things I had wanted to do//
/////////////////////////////

The player direction sometimes freaks out and switches directions.

Enemy despawns need to be quicker, as the enemies corpse can still cause damage to the player.

Player respawning is also broken.

I wanted to convert all the sounds to be 2d sounds. I had to change the rifle and pistol to use 2d sounds. The gunfire volume would change depending on which way the player was facing.

I also wanted to make it so every object is only limited to 2 movement directions. If you try hard enough the player can still go over the platforms. 

The crosshair isn't setup the best. I have it mounted to the soldiers hand with an offset. Which sort of works, until the reload animation plays.

The camera would also "jump" if an object with collision that got in between the player and the camera. 

These would probably already be solved by switching to a 2d game engine.



