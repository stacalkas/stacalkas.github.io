
singleton Material(TestPlatform_ColorEffectR224G86B86_material)
{
   mapTo = "ColorEffectR224G86B86-material";
   specular[0] = "1 1 1 1";
   specularPower[0] = "10";
   translucentBlendOp = "None";
   translucent = "0";
   alphaTest = "0";
   castShadows = "1";
   showFootprints = "0";
   diffuseColor[0] = "0.878431 0.337255 0.337255 1";
};

singleton Material(TestPlatform_ColorEffectR224G86B86_material)
{
   mapTo = "ColorEffectR224G86B86-material";
   diffuseColor[0] = "0.878431 0.337255 0.337255 1";
   specularPower[0] = "10";
   translucentBlendOp = "None";
};

singleton Material(TestPlatform__2___Default)
{
   mapTo = "_2_-_Default";
   diffuseMap[0] = "art/shapes/Platforms/images/0_wood_t1";
   specular[0] = "0.9 0.9 0.9 1";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   alphaTest = "1";
   castShadows = "0";
   translucent = "1";
   translucentZWrite = "1";
   showFootprints = "0";
};

singleton Material(TestPlatform__Soldierdefault)
{
   mapTo = "_Soldierdefault";
   diffuseMap[0] = "art/shapes/Platforms/images/0_Girder_D";
   specular[0] = "0.9 0.9 0.9 1";
   specularPower[0] = "1";
   translucentBlendOp = "LerpAlpha";
   castShadows = "0";
   alphaTest = "1";
   alphaRef = "255";
   showFootprints = "0";
};

singleton Material(TestPlatform_ColorEffectR225G87B143_material)
{
   mapTo = "ColorEffectR225G87B143-material";
   diffuseColor[0] = "0.882353 0.341177 0.560784 1";
   specularPower[0] = "10";
   translucentBlendOp = "None";
};

singleton Material(PrizeBox_ColorEffectR88G199B225_material)
{
   mapTo = "ColorEffectR88G199B225-material";
   diffuseColor[0] = "0.345098 0.780392 0.882353 1";
   specularPower[0] = "10";
   translucentBlendOp = "None";
};

singleton Material(PrizeBox)
{
   mapTo = "PrizeBox";
   diffuseMap[0] = "art/shapes/Platforms/images/0_TorqueLogo_D";
   specular[0] = "0.9 0.9 0.9 1";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   animFlags[0] = "0x0000000c";
   rotSpeed[0] = "-0.82";
   rotPivotOffset[0] = "-0.5 -0.5";
   castShadows = "0";
   showFootprints = "0";
   scrollDir[0] = "0.241 0.31";
   scrollSpeed[0] = "0.235";
   waveType[0] = "Square";
   waveFreq[0] = "0.938";
   waveAmp[0] = "1";
};

singleton Material(GGBlock)
{
   mapTo = "GGBlock";
   diffuseMap[0] = "art/shapes/Platforms/images/0_GGLogo_D";
   specular[0] = "0.9 0.9 0.9 1";
   specularPower[0] = "1";
   translucentBlendOp = "None";
};

singleton Material(Tree1_ColorEffectR108G8B136_material)
{
   mapTo = "ColorEffectR108G8B136-material";
   diffuseColor[0] = "0.423529 0.0313726 0.533333 1";
   specularPower[0] = "10";
   translucentBlendOp = "None";
};

singleton Material(Tree1)
{
   mapTo = "Tree1";
   diffuseMap[0] = "art/shapes/Platforms/images/0_Tree1_D";
   specular[0] = "0.9 0.9 0.9 1";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   castShadows = "0";
   alphaTest = "1";
   alphaRef = "174";
   showFootprints = "0";
};

singleton Material(Sky1)
{
   mapTo = "Sky1";
   diffuseMap[0] = "art/shapes/Platforms/images/0_Sky1_D";
   specular[0] = "0.9 0.9 0.9 1";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   emissive[0] = "1";
   animFlags[0] = "0x00000001";
   scrollDir[0] = "-0.07 0";
   scrollSpeed[0] = "0.471";
};

singleton Material(SpawnPoint1)
{
   mapTo = "SpawnPoint1";
   diffuseMap[0] = "art/shapes/Platforms/images/0_SpawnPoint1_D";
   specular[0] = "0.9 0.9 0.9 1";
   specularPower[0] = "1";
   translucentBlendOp = "None";
};

singleton Material(SpawnPoint2)
{
   mapTo = "SpawnPoint2";
   diffuseMap[0] = "art/shapes/Platforms/images/0_SpawnPoint2_D";
   specular[0] = "0.9 0.9 0.9 1";
   specularPower[0] = "1";
   translucentBlendOp = "None";
};

singleton Material(SpawnPoint3)
{
   mapTo = "SpawnPoint3";
   diffuseMap[0] = "art/shapes/Platforms/images/0_SpawnPoint3_D";
   specular[0] = "0.9 0.9 0.9 1";
   specularPower[0] = "1";
   translucentBlendOp = "None";
};


singleton Material(Platform_BG_Material)
{
   mapTo = "Platform_BG";
   translucentBlendOp = "None";
   diffuseMap[0] = "art/shapes/Platforms/images/CheckerBlue_D.png";
   specular[2] = "White";
};

singleton Material(Platform_Grass_Material)
{
   mapTo = "Material";
   diffuseMap[0] = "art/shapes/Platforms/images/Grass_D.png";
   translucentBlendOp = "None";
};

singleton Material(PlatformBG)
{
   mapTo = "PlatformBG";
   diffuseMap[0] = "art/shapes/Platforms/images/CheckerBlue_D";
   specular[0] = "0 0 0 1";
   specularPower[0] = "2";
   translucentBlendOp = "None";
};
