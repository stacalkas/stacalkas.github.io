
singleton TSShapeConstructor(Platform_GrassDAE)
{
   baseShape = "./Platform_Grass.DAE";
   loadLights = "0";
};
