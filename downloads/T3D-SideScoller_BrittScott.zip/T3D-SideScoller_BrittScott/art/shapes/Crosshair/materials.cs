
singleton Material(Crosshair3D__1___Default)
{
   mapTo = "_1_-_Default";
   diffuseMap[0] = "art/shapes/Crosshair/images/0_Test_D.png";
   specular[0] = "0.9 0.9 0.9 1";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   castShadows = "0";
   showFootprints = "0";
   doubleSided = "1";
   glow[0] = "1";
   emissive[0] = "1";
};
