//-----------------------------------------------------------------------------
// Copyright (c) 2012 GarageGames, LLC
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//-----------------------------------------------------------------------------



datablock ShapeBaseImageData(CrosshairImage)
{
   // FP refers to first person specific features
   
   // Defines what art file to use.
   shapeFile = "art/shapes/Crosshair/Crosshair3D.DAE";
   //shapeFileFP = "art/shapes/weapons/Lurker/FP_Lurker.DAE";
   
   // Whether or not to enable environment mapping
   //emap                           = true;

   //imageAnimPrefixFP              = "";

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint                       = 0;
   offset							= "0 3 0.5";
   //firstPerson                    = true;
   //eyeOffset                      = "0 1 0";
   
   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.
   //correctMuzzleVector            = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   class                            = "ReticleImage";
   className                        = "ReticleImage";

 
 
};